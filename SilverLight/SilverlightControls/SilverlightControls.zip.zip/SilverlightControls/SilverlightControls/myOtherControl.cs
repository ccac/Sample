using System.Windows.Controls;

namespace SilverlightControls
{
    public class myOtherControl : Control
    {

    }
}