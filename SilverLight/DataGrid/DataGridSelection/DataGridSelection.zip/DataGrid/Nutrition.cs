﻿using System;

namespace DataGrid
{
    public class Nutrition
    {
        public string Group { get; set; }

        public string Name { get; set; }

        public string Quantity { get; set; }
    }
}
