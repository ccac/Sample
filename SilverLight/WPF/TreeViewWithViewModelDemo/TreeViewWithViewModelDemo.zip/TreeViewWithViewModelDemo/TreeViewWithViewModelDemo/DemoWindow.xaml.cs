﻿using System.Windows;

namespace TreeViewWithViewModelDemo
{
    public partial class DemoWindow : Window
    {
        public DemoWindow()
        {
            InitializeComponent();
        }
    }
}